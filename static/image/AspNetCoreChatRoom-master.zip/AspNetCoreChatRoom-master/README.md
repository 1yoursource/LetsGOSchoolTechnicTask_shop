# AspNetCoreChatRoom
AspNetCoreChatRoom is simple WebSocket based chat room that works in browser. It is built on ASP.NET Core using Visual Studio 2017. This project has no business purpose and I'm using it as a support material for some of my presentations and blog posts.
